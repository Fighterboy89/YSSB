let isDisabled = false;

function disableExtension() {
  isDisabled = true;
}

function enableExtension() {
  isDisabled = false;
}

function isTextBoxFocused() {
  return document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA';
}

function preventSpacebarScroll(event) {
  if (!isDisabled && event.keyCode === 32) {
    event.preventDefault();
    const playPauseButton = document.querySelector('.ytp-play-button');
    playPauseButton.click();
  }
}

window.addEventListener('keydown', preventSpacebarScroll);
document.addEventListener('focusin', disableExtension);
document.addEventListener('focusout', enableExtension);
