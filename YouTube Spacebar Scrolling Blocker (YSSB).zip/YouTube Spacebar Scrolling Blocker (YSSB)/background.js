chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'disableExtension') {
    chrome.action.disable(sender.tab.id);
    sendResponse('Extension disabled');
  } else if (message.action === 'enableExtension') {
    chrome.action.enable(sender.tab.id);
    sendResponse('Extension enabled');
  }
});
